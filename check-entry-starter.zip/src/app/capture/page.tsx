"use client";
import { useState } from "react";

export default function Page() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");

  async function go(e){
    e.preventDefault();
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/process-check",{ method:"POST", body:fd });
    const data = await res.json();
    sessionStorage.setItem("reviewPayload", JSON.stringify(data));
    window.location.href="/review";
  }

  return (
    <main className='p-6'>
      <h1 className='text-xl font-bold'>Upload Check</h1>
      <form onSubmit={go}>
        <input type='file' accept='image/*'
          onChange={e=>{setFile(e.target.files[0]); setPreview(URL.createObjectURL(e.target.files[0]));}}
        />
        {preview && <img src={preview} className='mt-3 rounded' />}
        <button className='mt-3 px-4 py-2 bg-blue-600 text-white rounded'>Process</button>
      </form>
    </main>
  );
}
